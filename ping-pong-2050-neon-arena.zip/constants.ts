import { Ball, Paddle, PowerUp, SpeedOrb } from './types';

export const INITIAL_COINS = 100;

export const DEFAULT_BALL_ID = 'ball_default_cyan';
export const DEFAULT_PADDLE_ID = 'paddle_default_cyan';

export const BALLS: Ball[] = [
  {
    id: DEFAULT_BALL_ID,
    name: 'Cyber Orb',
    cost: 0,
    description: 'Standard issue cybernetic orb.',
    color: 'bg-cyan-400',
    glowColor: 'shadow-cyan-400/70',
    speedMultiplier: 1.0,
    vfx: 'trail', // Changed from 'pulse' in thought process, trail is more visually distinct for a default
  },
  {
    id: 'ball_hot_pink',
    name: 'Pink Comet',
    cost: 100,
    description: 'A swift comet, leaving a faint pink trail.',
    color: 'bg-pink-500',
    glowColor: 'shadow-pink-500/70',
    speedMultiplier: 1.1,
    vfx: 'trail',
  },
  {
    id: 'ball_emerald_green',
    name: 'Emerald Spark',
    cost: 250,
    description: 'Crackles with contained energy.',
    color: 'bg-emerald-500',
    glowColor: 'shadow-emerald-500/70',
    speedMultiplier: 1.15,
    vfx: 'burst',
  },
   {
    id: 'ball_golden_sun',
    name: 'Golden Sun',
    cost: 500,
    description: 'Radiates with solar power, moves with intensity.',
    color: 'bg-yellow-400',
    glowColor: 'shadow-yellow-400/70',
    speedMultiplier: 1.25,
    vfx: 'trail',
  },
  {
    id: 'ball_quantum_entangler',
    name: 'Quantum Entangler',
    cost: 750,
    description: 'An unpredictable orb with unstable energy.',
    color: 'bg-indigo-500',
    glowColor: 'shadow-indigo-500/70',
    speedMultiplier: 1.2,
    vfx: 'burst',
  },
  {
    id: 'ball_void_sphere',
    name: 'Void Sphere',
    cost: 1000,
    description: 'A dark sphere pulsing with unknown energy.',
    color: 'bg-gray-800',
    glowColor: 'shadow-purple-600/60',
    speedMultiplier: 1.3,
    vfx: 'trail',
  },
  {
    id: 'ball_photon_streak',
    name: 'Photon Streak',
    cost: 1200,
    description: 'Pure light energy, moves incredibly fast.',
    color: 'bg-yellow-200',
    glowColor: 'shadow-yellow-200/80',
    speedMultiplier: 1.4,
    vfx: 'trail'
  },
  {
    id: 'ball_dark_matter',
    name: 'Dark Matter Core',
    cost: 1500,
    description: 'Bends light around it. Deceptively quick.',
    color: 'bg-purple-900',
    glowColor: 'shadow-purple-400/60',
    speedMultiplier: 1.35,
    vfx: 'burst'
  }
];

export const PADDLES: Paddle[] = [
  {
    id: DEFAULT_PADDLE_ID,
    name: 'Vector Blade',
    cost: 0,
    description: 'Standard energy blade for precise returns.',
    color: 'bg-cyan-400',
    glowColor: 'shadow-cyan-400/70',
    widthModifier: 1.0,
    hitPowerMultiplier: 1.0,
    vfx: 'glow-hit',
  },
  {
    id: 'paddle_magenta_force',
    name: 'Magenta Shield',
    cost: 120,
    description: 'Wider field for enhanced defense.',
    color: 'bg-fuchsia-500',
    glowColor: 'shadow-fuchsia-500/70',
    widthModifier: 1.15,
    hitPowerMultiplier: 1.0,
    vfx: 'shield',
  },
  {
    id: 'paddle_azure_edge',
    name: 'Azure Striker',
    cost: 280,
    description: 'Channel focused energy for powerful shots.',
    color: 'bg-sky-500',
    glowColor: 'shadow-sky-500/70',
    widthModifier: 1.0,
    hitPowerMultiplier: 1.1,
    vfx: 'spark',
  },
  {
    id: 'paddle_obsidian_guard',
    name: 'Obsidian Wall',
    cost: 550,
    description: 'Imposing and resilient, a true defensive barrier.',
    color: 'bg-slate-700', 
    glowColor: 'shadow-purple-500/60',
    widthModifier: 1.25,
    hitPowerMultiplier: 1.05,
    vfx: 'shield',
  },
  {
    id: 'paddle_chrono_breaker',
    name: 'Chrono Breaker',
    cost: 700,
    description: 'A teal paddle that returns shots with extra force.',
    color: 'bg-teal-500',
    glowColor: 'shadow-teal-500/70',
    widthModifier: 1.05,
    hitPowerMultiplier: 1.15,
    vfx: 'spark',
  },
  {
    id: 'paddle_plasma_deflector',
    name: 'Plasma Deflector',
    cost: 900,
    description: 'Wide orange paddle for strong defense and powerful returns.',
    color: 'bg-orange-500',
    glowColor: 'shadow-orange-500/70',
    widthModifier: 1.2,
    hitPowerMultiplier: 1.1,
    vfx: 'shield',
  },
  {
    id: 'paddle_aegis_protector',
    name: 'Aegis Protector',
    cost: 1100,
    description: 'Ultimate defensive paddle with a wide energy field.',
    color: 'bg-gray-400',
    glowColor: 'shadow-sky-300/70',
    widthModifier: 1.3,
    hitPowerMultiplier: 1.0,
    vfx: 'shield'
  },
  {
    id: 'paddle_crimson_razor',
    name: 'Crimson Razor',
    cost: 1300,
    description: 'A lean paddle that channels immense power into shots.',
    color: 'bg-red-600',
    glowColor: 'shadow-red-500/70',
    widthModifier: 0.9,
    hitPowerMultiplier: 1.3,
    vfx: 'spark'
  }
];

export const POWER_UPS: PowerUp[] = [
    {
        id: 'powerup_2x_coins',
        name: 'Coin Doubler',
        description: 'Earn 2x coins for the next 3 matches.',
        cost: 200,
        effect: (playerData) => ({...playerData}) // Placeholder effect
    },
    {
        id: 'powerup_paddle_size',
        name: 'Paddle Enlarge',
        description: 'Increases your paddle size for 1 match.',
        cost: 150,
        effect: (playerData) => ({...playerData}) // Placeholder effect
    },
    {
        id: 'powerup_score_shield',
        name: 'Score Shield',
        description: 'Prevents opponent from scoring for their next point attempt (1 use).',
        cost: 250,
        effect: (playerData) => ({...playerData}) // Placeholder effect
    },
    {
        id: 'powerup_ball_camo',
        name: 'Ball Camo',
        description: 'Makes the ball harder to see for 10 seconds.',
        cost: 180,
        effect: (playerData) => ({...playerData}) // Placeholder effect
    },
];


// Game physics and layout constants
export const GAME_WIDTH = 800;
export const GAME_HEIGHT = 500;
export const PADDLE_WIDTH = 15; 
export const PADDLE_HEIGHT = 100;
export const BALL_RADIUS = 10;
export const PADDLE_SPEED = 5.5; // Base speed for paddles, matching Hard AI
export const BALL_SPEED_X_INITIAL = 5;
export const BALL_SPEED_Y_INITIAL = 3;
export const AI_PADDLE_SPEED_EASY = 3.5; 
export const AI_PADDLE_SPEED_MEDIUM = 4.5; 
export const AI_PADDLE_SPEED_HARD = 5.5; 

export const DEFAULT_WINNING_SCORE = 3;
export const MIN_POINTS_TO_WIN = 1;
export const MAX_POINTS_TO_WIN = 21;

export const COIN_REWARDS = { // Base rewards for DEFAULT_WINNING_SCORE (3 points)
    '1p-easy': 25,
    '1p-medium': 60,
    '1p-hard': 125,
    '2p': 40, // Winner (Player 1 if they win) gets coins
};

export const COIN_BONUS_PER_POINT_ABOVE_DEFAULT = {
    '1p-easy': 5,
    '1p-medium': 10,
    '1p-hard': 15,
    '2p': 7,
};


// Progressive ball speed
export const BALL_SPEED_INCREASE_PER_HIT = 0.15; // Additive increase
export const BALL_SPEED_INCREASE_PER_SECOND = 1.0; // Additive magnitude increase per second
export const MAX_BALL_SPEED_FACTOR = 2.5; // Max speed is initial_speed_of_equipped_ball * this factor

// Speed Orbs
export const ORB_RADIUS = 10; // Slightly larger for better visibility
export const ORB_TYPES = {
  green: { boostAmount: 5, boostDuration: 5000, color: 'bg-green-500', glowColor: 'shadow-green-500/70', spawnWeight: 6 },
  blue:  { boostAmount: 10, boostDuration: 5000, color: 'bg-blue-500', glowColor: 'shadow-blue-500/70', spawnWeight: 3 },
  red:   { boostAmount: 20, boostDuration: 5000, color: 'bg-red-500', glowColor: 'shadow-red-500/70', spawnWeight: 1 },
};
export const MAX_ORBS_ON_SCREEN = 3;
export const MIN_ORB_SPAWN_INTERVAL = 5000; // ms
export const MAX_ORB_SPAWN_INTERVAL = 10000; // ms


// VFX Constants
export const VFX_TRAIL_LENGTH = 8;
export const VFX_PARTICLE_COUNT = 15;
export const VFX_PARTICLE_LIFESPAN_FRAMES = 30; // Approx 0.5s at 60fps
export const VFX_PADDLE_EFFECT_DURATION = 200; // ms