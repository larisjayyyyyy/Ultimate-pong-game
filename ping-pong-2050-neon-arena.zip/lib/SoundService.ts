// lib/SoundService.ts

// Define sound file paths (these are placeholders)
// In a real project, these .wav or .mp3 files would exist in your public/sfx directory.
export const SOUND_FILES = {
  CLICK: '/sfx/ui_click.wav',
  NAVIGATE: '/sfx/ui_navigate.wav',
  PADDLE_HIT: '/sfx/paddle_hit.wav',
  WALL_HIT: '/sfx/wall_hit.wav',
  SCORE_P1: '/sfx/score_p1.wav',
  SCORE_P2: '/sfx/score_p2.wav',
  GAME_OVER_WIN: '/sfx/game_over_win.wav',
  GAME_OVER_LOSE: '/sfx/game_over_lose.wav',
  ORB_SPAWN: '/sfx/orb_spawn.wav',
  ORB_COLLECT: '/sfx/orb_collect.wav',
  BUY_ITEM: '/sfx/buy_item.wav',
  EQUIP_ITEM: '/sfx/equip_item.wav',
  COIN_COLLECT: '/sfx/coin_collect.wav',
  SERVE: '/sfx/serve.wav',
  PAUSE: '/sfx/pause.wav',
  RESUME: '/sfx/resume.wav',
  MODAL_OPEN: '/sfx/modal_open.wav',
  MODAL_CLOSE: '/sfx/modal_close.wav',
  ERROR: '/sfx/error.wav', // For insufficient funds, failed actions etc.
  POWERUP_ACTIVATE: '/sfx/powerup_activate.wav', // Placeholder
};

export type SoundKey = keyof typeof SOUND_FILES;

const playSound = (soundKey: SoundKey, volume: number = 0.7): void => {
  try {
    const soundSrc = SOUND_FILES[soundKey];
    if (!soundSrc) {
      console.warn(`Sound key "${soundKey}" not found in SOUND_FILES.`);
      return;
    }

    // Create a new Audio object each time to allow sounds to overlap.
    // For high-frequency sounds, an AudioContext pool might be more performant,
    // but this is generally fine for typical UI/game sound effects.
    const audio = new Audio(soundSrc);
    audio.volume = Math.max(0, Math.min(1, volume)); // Ensure volume is between 0 and 1
    
    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(error => {
        // Autoplay restrictions are common. Usually, sounds triggered by direct user interaction are allowed.
        if (error.name === 'NotAllowedError') {
          // console.warn(`Autoplay prevented for sound: ${soundKey}. User interaction might be required first.`);
        } else {
          // This can happen if the sound file doesn't exist or is corrupted.
          // console.error(`Error playing sound ${soundKey} (source: ${soundSrc}):`, error);
        }
      });
    }
  } catch (e) {
    // console.error(`Failed to initialize or play sound ${soundKey}:`, e);
  }
};

export default playSound;
