
export interface GameItem {
  id: string;
  name: string;
  cost: number;
  description: string;
  color: string; // hex or tailwind color for the item itself
  glowColor: string; // tailwind color for glow effect
  asset?: string; // Path to an SVG or image if used
}

export interface Ball extends GameItem {
  speedMultiplier: number;
  vfx?: 'trail' | 'burst';
}

export interface Paddle extends GameItem {
  widthModifier: number; // e.g., 1.0 for normal, 1.2 for 20% wider
  hitPowerMultiplier: number;
  vfx?: 'shield' | 'spark' | 'glow-hit';
}

export enum GameMode {
  OnePVsAI_Easy = '1p-easy',
  OnePVsAI_Medium = '1p-medium',
  OnePVsAI_Hard = '1p-hard',
  TwoPlayer = '2p',
}

export interface PlayerData {
  coins: number;
  ownedBallIds: string[];
  ownedPaddleIds: string[];
  equippedBallId: string;
  equippedPaddleId: string;
  powerUps: { [key: string]: number }; // e.g., { "2xCoins": 1 (timestamp of expiry or count) }
}

export interface PowerUp {
  id: string;
  name: string;
  description: string;
  cost: number;
  duration?: number; // in seconds, or matches
  effect: (playerData: PlayerData) => PlayerData; // or directly modifies game state
}

export enum GameState {
  Loading = 'LOADING',
  MainMenu = 'MAIN_MENU',
  Playing = 'PLAYING',
  Paused = 'PAUSED',
  GameOver = 'GAME_OVER',
  Shop = 'SHOP',
  Settings = 'SETTINGS',
  Customize = 'CUSTOMIZE',
}

export type OrbType = 'green' | 'blue' | 'red';

export interface SpeedOrb {
  id: string;
  x: number;
  y: number;
  radius: number;
  active: boolean; // Remains true, actual presence in array means active
  color: string; // Tailwind bg color class
  glowColor: string; // Tailwind shadow class
  type: OrbType;
  boostAmount: number;
  boostDuration: number; // in milliseconds
}

export interface ActiveBoost {
  id: string; // Unique ID for this boost instance
  boostAmount: number;
  expiresAt: number; // Timestamp
  orbType: OrbType; // To potentially prevent re-triggering same type if needed later
}
