
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import MainMenuScreen from './components/screens/MainMenuScreen';
import GameScreen from './components/screens/GameScreen';
import ShopScreen from './components/screens/ShopScreen';
import CustomizeScreen from './components/screens/CustomizeScreen';
import SettingsScreen from './components/screens/SettingsScreen';
import LoadingScreen from './components/screens/LoadingScreen';
import { PlayerDataProvider } from './hooks/usePlayerData';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate asset loading or initial setup
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500); // Adjust loading time as needed
    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <PlayerDataProvider>
      <HashRouter>
        <div className="min-h-screen flex flex-col items-center justify-center bg-slate-950 p-4 font-[Orbitron,sans-serif]">
          <Routes>
            <Route path="/" element={<MainMenuScreen />} />
            <Route path="/play/:mode/:points" element={<GameScreen />} />
            <Route path="/shop" element={<ShopScreen />} />
            <Route path="/customize" element={<CustomizeScreen />} />
            <Route path="/settings" element={<SettingsScreen />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </div>
      </HashRouter>
    </PlayerDataProvider>
  );
};

export default App;