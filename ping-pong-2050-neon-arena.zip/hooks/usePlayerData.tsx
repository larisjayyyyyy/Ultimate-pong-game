
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { PlayerData, Ball, Paddle } from '../types';
import { INITIAL_COINS, DEFAULT_BALL_ID, DEFAULT_PADDLE_ID, BALLS, PADDLES } from '../constants';
import playSound, { SOUND_FILES, SoundKey } from '../lib/SoundService';

interface PlayerDataContextType {
  playerData: PlayerData;
  setPlayerData: React.Dispatch<React.SetStateAction<PlayerData>>;
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => boolean; // This remains for internal use, sound is handled by callers like buyBall
  buyBall: (ball: Ball) => boolean;
  buyPaddle: (paddle: Paddle) => boolean;
  equipBall: (ballId: string) => void;
  equipPaddle: (paddleId: string) => void;
  isBallOwned: (ballId: string) => boolean;
  isPaddleOwned: (paddleId: string) => boolean;
  getEquippedBall: () => Ball;
  getEquippedPaddle: () => Paddle;
}

const PlayerDataContext = createContext<PlayerDataContextType | undefined>(undefined);

const getInitialPlayerData = (): PlayerData => {
  const savedData = localStorage.getItem('pingPongPlayerData');
  if (savedData) {
    const parsedData = JSON.parse(savedData) as PlayerData;
    if (!parsedData.ownedBallIds.includes(DEFAULT_BALL_ID)) {
      parsedData.ownedBallIds.push(DEFAULT_BALL_ID);
    }
    if (!parsedData.ownedPaddleIds.includes(DEFAULT_PADDLE_ID)) {
      parsedData.ownedPaddleIds.push(DEFAULT_PADDLE_ID);
    }
    return parsedData;
  }
  return {
    coins: INITIAL_COINS,
    ownedBallIds: [DEFAULT_BALL_ID],
    ownedPaddleIds: [DEFAULT_PADDLE_ID],
    equippedBallId: DEFAULT_BALL_ID,
    equippedPaddleId: DEFAULT_PADDLE_ID,
    powerUps: {},
  };
};


export const PlayerDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [playerData, setPlayerData] = useState<PlayerData>(getInitialPlayerData);

  useEffect(() => {
    localStorage.setItem('pingPongPlayerData', JSON.stringify(playerData));
  }, [playerData]);

  const addCoins = (amount: number) => {
    if (amount > 0) {
        playSound('COIN_COLLECT');
    }
    setPlayerData(prev => ({ ...prev, coins: prev.coins + amount }));
  };

  const spendCoins = (amount: number): boolean => {
    if (playerData.coins >= amount) {
      setPlayerData(prev => ({ ...prev, coins: prev.coins - amount }));
      return true;
    }
    return false;
  };

  const buyBall = (ball: Ball): boolean => {
    if (playerData.coins >= ball.cost && !playerData.ownedBallIds.includes(ball.id)) {
      if (spendCoins(ball.cost)) {
        setPlayerData(prev => ({ ...prev, ownedBallIds: [...prev.ownedBallIds, ball.id] }));
        playSound('BUY_ITEM');
        return true;
      }
    }
    playSound('ERROR');
    return false;
  };

  const buyPaddle = (paddle: Paddle): boolean => {
    if (playerData.coins >= paddle.cost && !playerData.ownedPaddleIds.includes(paddle.id)) {
       if (spendCoins(paddle.cost)) {
        setPlayerData(prev => ({ ...prev, ownedPaddleIds: [...prev.ownedPaddleIds, paddle.id] }));
        playSound('BUY_ITEM');
        return true;
      }
    }
    playSound('ERROR');
    return false;
  };

  const equipBall = (ballId: string) => {
    if (playerData.ownedBallIds.includes(ballId)) {
      setPlayerData(prev => ({ ...prev, equippedBallId: ballId }));
      playSound('EQUIP_ITEM');
    }
  };

  const equipPaddle = (paddleId: string) => {
    if (playerData.ownedPaddleIds.includes(paddleId)) {
      setPlayerData(prev => ({ ...prev, equippedPaddleId: paddleId }));
      playSound('EQUIP_ITEM');
    }
  };
  
  const isBallOwned = (ballId: string) => playerData.ownedBallIds.includes(ballId);
  const isPaddleOwned = (paddleId: string) => playerData.ownedPaddleIds.includes(paddleId);

  const getEquippedBall = (): Ball => {
    return BALLS.find(b => b.id === playerData.equippedBallId) || BALLS[0];
  };

  const getEquippedPaddle = (): Paddle => {
    return PADDLES.find(p => p.id === playerData.equippedPaddleId) || PADDLES[0];
  };

  return (
    <PlayerDataContext.Provider value={{ 
        playerData, setPlayerData, addCoins, spendCoins, 
        buyBall, buyPaddle, equipBall, equipPaddle,
        isBallOwned, isPaddleOwned, getEquippedBall, getEquippedPaddle
      }}>
      {children}
    </PlayerDataContext.Provider>
  );
};

export const usePlayerData = (): PlayerDataContextType => {
  const context = useContext(PlayerDataContext);
  if (context === undefined) {
    throw new Error('usePlayerData must be used within a PlayerDataProvider');
  }
  return context;
};
