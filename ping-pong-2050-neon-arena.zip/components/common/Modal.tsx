
import React, { ReactNode, useEffect, useRef } from 'react';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  const prevIsOpen = useRef(isOpen);

  useEffect(() => {
    if (isOpen && !prevIsOpen.current) {
      playSound('MODAL_OPEN');
    }
    prevIsOpen.current = isOpen;
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClose = () => {
    playSound('MODAL_CLOSE');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border-2 border-cyan-500 rounded-xl shadow-2xl shadow-cyan-500/30 w-full max-w-md transform transition-all">
        <div className="flex justify-between items-center p-4 border-b border-slate-700">
          <h2 className="text-2xl font-bold text-cyan-400 neon-text-cyan">{title}</h2>
          <button
            onClick={handleClose}
            className="text-slate-400 hover:text-pink-500 transition-colors text-2xl"
            aria-label="Close modal"
          >
            &times;
          </button>
        </div>
        <div className="p-6 text-slate-300">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Modal;
