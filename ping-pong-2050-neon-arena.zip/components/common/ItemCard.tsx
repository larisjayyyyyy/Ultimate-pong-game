
import React from 'react';
import { GameItem } from '../../types';
import NeonButton from './NeonButton';

interface ItemCardProps {
  item: GameItem;
  onAction?: () => void;
  actionLabel?: string;
  isOwned?: boolean;
  isEquipped?: boolean;
  onEquip?: () => void;
  canAfford?: boolean;
}

const ItemCard: React.FC<ItemCardProps> = ({ item, onAction, actionLabel, isOwned, isEquipped, onEquip, canAfford = true }) => {
  const glowEffect = `shadow-[0_0_15px_4px_var(--glow-color)]`;
  const glowColorVar = item.glowColor.replace('shadow-', '').split('/')[0]; // e.g., cyan-400
  
  const dynamicGlowStyle = { '--glow-color': `rgba(var(--${glowColorVar}), 0.7)` } as React.CSSProperties;
  
  const colorMap: { [key: string]: string } = {
    'cyan-400': '6, 182, 212',
    'pink-500': '236, 72, 153',
    'emerald-500': '16, 185, 129',
    'yellow-400': '250, 204, 21',
    'fuchsia-500': '217, 70, 239',
    'sky-500': '14, 165, 233',
    'purple-500': '168, 85, 247',
    'slate-700': '51, 65, 85',
    'indigo-500': '99, 102, 241',
    'purple-600': '147, 51, 234',
    'teal-500': '20, 184, 166',
    'orange-500': '249, 115, 22',
    'yellow-200': '254, 240, 138', // For Photon Streak
    'purple-400': '168, 85, 247', // For Dark Matter Core glow (similar to purple-500)
    'sky-300': '125, 211, 252',   // For Aegis Protector glow
    'red-500': '239, 68, 68',     // For Crimson Razor glow
    'amber-500': '245, 158, 11',  // For Speed Orbs
  };
  if (colorMap[glowColorVar]) {
     dynamicGlowStyle['--glow-color'] = `rgba(${colorMap[glowColorVar]}, 0.6)`;
  }


  return (
    <div 
      className={`bg-slate-800 border-2 rounded-lg p-4 flex flex-col items-center gap-3 transition-all duration-300 hover:scale-105 ${isEquipped ? 'border-yellow-400 neon-border-yellow' : 'border-slate-700 hover:border-cyan-500'} ${isEquipped ? glowEffect : ''}`}
      style={isEquipped ? dynamicGlowStyle : {}}
    >
      <div className={`w-16 h-16 rounded-full ${item.color} flex items-center justify-center text-2xl font-bold ${item.glowColor} shadow-lg`}>
        {/* Icon or representation */}
        {item.name.substring(0,1)}
      </div>
      <h3 className="text-xl font-bold text-slate-100">{item.name}</h3>
      <p className="text-sm text-slate-400 text-center h-10 overflow-y-auto">{item.description}</p>
      
      {isOwned ? (
        isEquipped ? (
          <span className="text-yellow-400 font-semibold">Equipped</span>
        ) : (
          onEquip && <NeonButton onClick={onEquip} color="emerald" size="sm">Equip</NeonButton>
        )
      ) : (
        actionLabel && onAction && (
          <NeonButton onClick={onAction} disabled={!canAfford} color="cyan" size="sm">
            {actionLabel} ({item.cost} Coins)
          </NeonButton>
        )
      )}
      {!isOwned && !canAfford && <p className="text-xs text-red-500">Not enough coins</p>}
    </div>
  );
};

export default ItemCard;
