
import React from 'react';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';

interface NeonButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  color?: 'cyan' | 'pink' | 'emerald' | 'yellow';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const NeonButton: React.FC<NeonButtonProps> = ({ children, color = 'cyan', className = '', size = 'md', onClick, ...props }) => {
  const colorClasses = {
    cyan: 'border-cyan-400 text-cyan-400 hover:bg-cyan-400/20 focus:ring-cyan-500 shadow-[0_0_8px_1px_rgba(6,182,212,0.3)] hover:shadow-[0_0_15px_3px_rgba(6,182,212,0.5)]',
    pink: 'border-pink-500 text-pink-500 hover:bg-pink-500/20 focus:ring-pink-600 shadow-[0_0_8px_1px_rgba(236,72,153,0.3)] hover:shadow-[0_0_15px_3px_rgba(236,72,153,0.5)]',
    emerald: 'border-emerald-500 text-emerald-500 hover:bg-emerald-500/20 focus:ring-emerald-600 shadow-[0_0_8px_1px_rgba(16,185,129,0.3)] hover:shadow-[0_0_15px_3px_rgba(16,185,129,0.5)]',
    yellow: 'border-yellow-400 text-yellow-400 hover:bg-yellow-400/20 focus:ring-yellow-500 shadow-[0_0_8px_1px_rgba(250,204,21,0.3)] hover:shadow-[0_0_15px_3px_rgba(250,204,21,0.5)]',
  };

  const sizeClasses = {
    sm: 'py-1.5 px-3 text-sm',
    md: 'py-2 px-5 text-base',
    lg: 'py-3 px-7 text-lg',
  }

  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    playSound('CLICK');
    if (onClick) {
      onClick(event);
    }
  };

  return (
    <button
      className={`font-[Orbitron,sans-serif] border-2 rounded-lg font-bold transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-opacity-50 disabled:opacity-50 disabled:cursor-not-allowed ${colorClasses[color]} ${sizeClasses[size]} ${className}`}
      onClick={handleClick}
      {...props}
    >
      {children}
    </button>
  );
};

export default NeonButton;
