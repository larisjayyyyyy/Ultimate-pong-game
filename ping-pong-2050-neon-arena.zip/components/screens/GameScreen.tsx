
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { GameMode, SpeedOrb, ActiveBoost, OrbType } from '../../types';
import { usePlayerData } from '../../hooks/usePlayerData';
import { 
  GAME_WIDTH, GAME_HEIGHT, PADDLE_WIDTH as BASE_PADDLE_WIDTH, PADDLE_HEIGHT, BALL_RADIUS, 
  PADDLE_SPEED, BALL_SPEED_X_INITIAL, BALL_SPEED_Y_INITIAL, 
  DEFAULT_WINNING_SCORE, COIN_REWARDS, COIN_BONUS_PER_POINT_ABOVE_DEFAULT,
  AI_PADDLE_SPEED_EASY, AI_PADDLE_SPEED_MEDIUM, AI_PADDLE_SPEED_HARD,
  BALL_SPEED_INCREASE_PER_HIT, BALL_SPEED_INCREASE_PER_SECOND, MAX_BALL_SPEED_FACTOR,
  ORB_TYPES, MAX_ORBS_ON_SCREEN, MIN_ORB_SPAWN_INTERVAL, MAX_ORB_SPAWN_INTERVAL, ORB_RADIUS,
  VFX_TRAIL_LENGTH, VFX_PARTICLE_COUNT, VFX_PARTICLE_LIFESPAN_FRAMES, VFX_PADDLE_EFFECT_DURATION
} from '../../constants';
import NeonButton from '../common/NeonButton';
import Modal from '../common/Modal';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';

const TOUCH_P1_UP = 'touch_p1_up';
const TOUCH_P1_DOWN = 'touch_p1_down';
const TOUCH_P2_UP = 'touch_p2_up';
const TOUCH_P2_DOWN = 'touch_p2_down';

interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}

interface PaddleEffect {
  type: 'shield' | 'glow-hit' | null;
  activeUntil: number;
  currentGlow?: string; // For glow-hit
}

const calculateMatchReward = (mode: GameMode, targetPoints: number): number => {
    const baseReward = COIN_REWARDS[mode as keyof typeof COIN_REWARDS] || 0;
    if (targetPoints <= 0) return 0;
  
    const bonusPoints = Math.max(0, targetPoints - DEFAULT_WINNING_SCORE);
    const bonusPerPoint = COIN_BONUS_PER_POINT_ABOVE_DEFAULT[mode as keyof typeof COIN_BONUS_PER_POINT_ABOVE_DEFAULT] || 0;
    
    return baseReward + (bonusPoints * bonusPerPoint);
};


const GameScreen: React.FC = () => {
  const { mode: modeString, points: pointsString } = useParams<{ mode: string; points?: string }>();
  const navigate = useNavigate();
  const { playerData, addCoins, getEquippedBall, getEquippedPaddle } = usePlayerData();
  
  const mode = modeString as GameMode; 
  const currentWinningScore = pointsString ? parseInt(pointsString, 10) : DEFAULT_WINNING_SCORE;
  if (isNaN(currentWinningScore) || currentWinningScore < 1) {
    navigate('/'); 
  }

  const equippedBall = getEquippedBall();
  const equippedPaddle = getEquippedPaddle();

  const PADDLE_WIDTH = BASE_PADDLE_WIDTH * equippedPaddle.widthModifier;
  const BASE_BALL_SPEED_X = BALL_SPEED_X_INITIAL * equippedBall.speedMultiplier;
  const BASE_BALL_SPEED_Y = BALL_SPEED_Y_INITIAL * equippedBall.speedMultiplier;
  const MAX_ALLOWABLE_SPEED = Math.sqrt(BASE_BALL_SPEED_X**2 + BASE_BALL_SPEED_Y**2) * MAX_BALL_SPEED_FACTOR;

  const [ball, setBall] = useState({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2, vx: BASE_BALL_SPEED_X, vy: BASE_BALL_SPEED_Y });
  const [player1PaddleY, setPlayer1PaddleY] = useState(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
  const [player2PaddleY, setPlayer2PaddleY] = useState(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
  const [scores, setScores] = useState({ player1: 0, player2: 0 });
  const [gameState, setGameState] = useState<'PRE_SERVE' | 'PLAYING' | 'GAME_OVER' | 'PAUSED'>('PRE_SERVE');
  const [winner, setWinner] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({ title: '', message: ''});
  
  const [speedOrbs, setSpeedOrbs] = useState<SpeedOrb[]>([]);
  const [activeBoosts, setActiveBoosts] = useState<ActiveBoost[]>([]);
  const nextOrbSpawnTime = useRef<number>(Date.now() + MIN_ORB_SPAWN_INTERVAL + Math.random() * (MAX_ORB_SPAWN_INTERVAL - MIN_ORB_SPAWN_INTERVAL));
  const orbSpawnTimerId = useRef<number | null>(null);

  const [ballTrail, setBallTrail] = useState<{ x: number, y: number, opacity: number }[]>([]);
  const [activeParticles, setActiveParticles] = useState<Particle[]>([]);
  const [paddle1Effect, setPaddle1Effect] = useState<PaddleEffect>({ type: null, activeUntil: 0 });
  const [paddle2Effect, setPaddle2Effect] = useState<PaddleEffect>({ type: null, activeUntil: 0 });

  const gameAreaRef = useRef<HTMLDivElement>(null);
  const keysPressed = useRef<{ [key: string]: boolean }>({});
  const gameLoopFrameId = useRef<number | null>(null);
  const prevGameState = useRef(gameState);


  const colorToVarStyle = (tailwindColorClass: string) => {
    const colorMap: {[key:string]: string} = {
        'cyan-400': '#22d3ee', 'pink-500': '#ec4899', 'emerald-500': '#10b981',
        'yellow-400': '#facc15', 'fuchsia-500': '#d946ef', 'sky-500': '#0ea5e9',
        'slate-700': '#334155', 'indigo-500': '#6366f1', 'gray-800': '#1f2937',
        'teal-500': '#14b8a6', 'orange-500': '#f97316', 'yellow-200': '#fef08a',
        'purple-900': '#581c87', 'gray-400': '#9ca3af', 'red-600': '#dc2626',
        'amber-500': '#f59e0b',
        'green-500': '#22c55e', 'blue-500': '#3b82f6', 
    };
    const colorKey = tailwindColorClass.replace('bg-', '');
    return colorMap[colorKey] || tailwindColorClass; 
  }
  
  const createParticles = (x: number, y: number, count: number, colorClass: string, baseSpeed: number = 3) => {
    const newParticles: Particle[] = [];
    const particleColor = colorToVarStyle(colorClass);
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * baseSpeed + 1;
      newParticles.push({
        id: `particle-${Date.now()}-${i}`,
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: VFX_PARTICLE_LIFESPAN_FRAMES,
        color: particleColor,
        size: Math.random() * 2 + 2,
      });
    }
    setActiveParticles(prev => [...prev, ...newParticles]);
  };

  const spawnNewOrb = useCallback(() => {
    if (speedOrbs.length >= MAX_ORBS_ON_SCREEN) return;
    playSound('ORB_SPAWN', 0.6);
    const totalWeight = Object.values(ORB_TYPES).reduce((sum, type) => sum + type.spawnWeight, 0);
    let randomWeight = Math.random() * totalWeight;
    let selectedTypeKey: OrbType = 'green'; 

    for (const key in ORB_TYPES) {
        const type = ORB_TYPES[key as OrbType];
        if (randomWeight <= type.spawnWeight) {
            selectedTypeKey = key as OrbType;
            break;
        }
        randomWeight -= type.spawnWeight;
    }
    
    const orbConfig = ORB_TYPES[selectedTypeKey];
    const newOrb: SpeedOrb = {
        id: `orb-${Date.now()}-${Math.random()}`,
        x: GAME_WIDTH * (0.2 + Math.random() * 0.6), 
        y: GAME_HEIGHT * (0.1 + Math.random() * 0.8), 
        radius: ORB_RADIUS,
        active: true, 
        color: orbConfig.color,
        glowColor: orbConfig.glowColor,
        type: selectedTypeKey,
        boostAmount: orbConfig.boostAmount,
        boostDuration: orbConfig.boostDuration,
    };
    setSpeedOrbs(prevOrbs => [...prevOrbs, newOrb]);
  }, [speedOrbs.length]);

  useEffect(() => {
    if (gameState === 'PLAYING') {
        const attemptSpawn = () => {
            if (Date.now() >= nextOrbSpawnTime.current) {
                spawnNewOrb();
                nextOrbSpawnTime.current = Date.now() + MIN_ORB_SPAWN_INTERVAL + Math.random() * (MAX_ORB_SPAWN_INTERVAL - MIN_ORB_SPAWN_INTERVAL);
            }
            orbSpawnTimerId.current = window.setTimeout(attemptSpawn, 1000); 
        };
        attemptSpawn(); 
    } else {
        if (orbSpawnTimerId.current) clearTimeout(orbSpawnTimerId.current);
    }
    return () => {
        if (orbSpawnTimerId.current) clearTimeout(orbSpawnTimerId.current);
    };
  }, [gameState, spawnNewOrb]);


  const resetBall = useCallback((serverPlayer: 1 | 2) => {
    setBall({
      x: GAME_WIDTH / 2,
      y: GAME_HEIGHT / 2,
      vx: (serverPlayer === 1 ? BASE_BALL_SPEED_X : -BASE_BALL_SPEED_X) * (Math.random() > 0.5 ? 1 : -1),
      vy: BASE_BALL_SPEED_Y * (Math.random() > 0.5 ? 1 : -1) * (Math.random() * 0.5 + 0.75),
    });
    // Sound for serve/round start will be handled by gameState transition effect
    setGameState('PRE_SERVE');
    setSpeedOrbs([]);
    setActiveBoosts([]);
    nextOrbSpawnTime.current = Date.now() + MIN_ORB_SPAWN_INTERVAL + Math.random() * (MAX_ORB_SPAWN_INTERVAL - MIN_ORB_SPAWN_INTERVAL);
    if (orbSpawnTimerId.current) clearTimeout(orbSpawnTimerId.current);
    setBallTrail([]);
    setActiveParticles([]);
  }, [BASE_BALL_SPEED_X, BASE_BALL_SPEED_Y]);

  const resetGame = useCallback(() => { 
    setScores({ player1: 0, player2: 0 });
    setWinner(null);
    resetBall(Math.random() > 0.5 ? 1 : 2); // This will set gameState to PRE_SERVE
    setPlayer1PaddleY(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
    setPlayer2PaddleY(GAME_HEIGHT / 2 - PADDLE_HEIGHT / 2);
    setIsModalOpen(false);
  }, [resetBall]);


  useEffect(() => {
    if (gameState === 'PAUSED' && prevGameState.current !== 'PAUSED') {
      playSound('PAUSE');
    } else if (gameState === 'PLAYING' && prevGameState.current === 'PAUSED') {
      playSound('RESUME');
    } else if (gameState === 'PLAYING' && prevGameState.current === 'PRE_SERVE') {
      playSound('SERVE');
    }
    prevGameState.current = gameState;
  }, [gameState]);


  useEffect(() => {
    if (gameState !== 'PLAYING') {
       if (gameLoopFrameId.current) cancelAnimationFrame(gameLoopFrameId.current);
       gameLoopFrameId.current = null;
       return;
    }

    let lastTime = performance.now();

    const gameLoop = (currentTime: number) => {
      const deltaTime = (currentTime - lastTime) / 1000; 
      lastTime = currentTime;

      setActiveBoosts(prevBoosts => prevBoosts.filter(boost => boost.expiresAt > Date.now()));
      const totalCurrentBoost = activeBoosts.reduce((sum, boost) => sum + boost.boostAmount, 0);

      setBallTrail(prevTrail => {
        if (equippedBall.vfx === 'trail') {
          const newTrail = [{ x: ball.x, y: ball.y, opacity: 1.0 }, ...prevTrail];
          return newTrail.slice(0, VFX_TRAIL_LENGTH).map((p, i) => ({ ...p, opacity: 1.0 - (i / VFX_TRAIL_LENGTH) }));
        }
        return [];
      });

      setActiveParticles(prevParticles => 
        prevParticles.map(p => ({
          ...p, x: p.x + p.vx, y: p.y + p.vy, life: p.life - 1,
        })).filter(p => p.life > 0)
      );

      if (paddle1Effect.type && Date.now() > paddle1Effect.activeUntil) setPaddle1Effect({ type: null, activeUntil: 0 });
      if (paddle2Effect.type && Date.now() > paddle2Effect.activeUntil) setPaddle2Effect({ type: null, activeUntil: 0 });
      
      setBall(prevBall => {
        let { x, y, vx, vy } = prevBall;

        if (totalCurrentBoost > 0) {
            const currentSpeedMagnitude = Math.sqrt(vx * vx + vy * vy);
            if (currentSpeedMagnitude > 0.001) { 
                const targetSpeedMagnitude = currentSpeedMagnitude + totalCurrentBoost * deltaTime * 5; 
                const scaleFactor = targetSpeedMagnitude / currentSpeedMagnitude;
                vx *= scaleFactor; vy *= scaleFactor;
            } else { 
                const angle = Math.random() * Math.PI * 2;
                vx = Math.cos(angle) * totalCurrentBoost; vy = Math.sin(angle) * totalCurrentBoost;
            }
        }

        let currentSpeedMagnitude = Math.sqrt(vx*vx + vy*vy);
        if (currentSpeedMagnitude > 0.001 && currentSpeedMagnitude < MAX_ALLOWABLE_SPEED) {
          const increaseAmount = BALL_SPEED_INCREASE_PER_SECOND * deltaTime;
          let targetSpeedMag = currentSpeedMagnitude + increaseAmount;
          targetSpeedMag = Math.min(targetSpeedMag, MAX_ALLOWABLE_SPEED);
          if (targetSpeedMag > currentSpeedMagnitude) {
            const speedRatio = targetSpeedMag / currentSpeedMagnitude;
            vx *= speedRatio; vy *= speedRatio;
          }
        }

        let newX = x + vx; let newY = y + vy;
        let newVx = vx; let newVy = vy;

        if (newY - BALL_RADIUS < 0 || newY + BALL_RADIUS > GAME_HEIGHT) {
          newVy = -newVy;
          newY = newY - BALL_RADIUS < 0 ? BALL_RADIUS : GAME_HEIGHT - BALL_RADIUS;
          playSound('WALL_HIT', 0.6);
        }

        let hit = false; let hitPaddle: 1 | 2 | null = null;

        if (newX - BALL_RADIUS < PADDLE_WIDTH && newX - BALL_RADIUS > 0 && newVx < 0 &&
            newY + BALL_RADIUS > player1PaddleY && newY - BALL_RADIUS < player1PaddleY + PADDLE_HEIGHT) {
          newVx = Math.abs(newVx) * equippedPaddle.hitPowerMultiplier;
          const hitSpot = (newY - (player1PaddleY + PADDLE_HEIGHT / 2)) / (PADDLE_HEIGHT / 2);
          newVy = hitSpot * 5 * equippedPaddle.hitPowerMultiplier; 
          newX = PADDLE_WIDTH + BALL_RADIUS;
          hit = true; hitPaddle = 1;
        }
        else if (newX + BALL_RADIUS > GAME_WIDTH - PADDLE_WIDTH && newX + BALL_RADIUS < GAME_WIDTH && newVx > 0 &&
                 newY + BALL_RADIUS > player2PaddleY && newY - BALL_RADIUS < player2PaddleY + PADDLE_HEIGHT) {
          newVx = -Math.abs(newVx) * equippedPaddle.hitPowerMultiplier;
          const hitSpot = (newY - (player2PaddleY + PADDLE_HEIGHT / 2)) / (PADDLE_HEIGHT / 2);
          newVy = hitSpot * 5 * equippedPaddle.hitPowerMultiplier;
          newX = GAME_WIDTH - PADDLE_WIDTH - BALL_RADIUS;
          hit = true; hitPaddle = 2;
        }

        if (hit) {
          playSound('PADDLE_HIT');
          let speedAfterHitEffect = Math.sqrt(newVx**2 + newVy**2);
          let targetSpeedAfterHit = speedAfterHitEffect + BALL_SPEED_INCREASE_PER_HIT;
          if (speedAfterHitEffect > 0.001) {
            const ratio = targetSpeedAfterHit / speedAfterHitEffect;
            newVx *= ratio; newVy *= ratio;
          }
          if (equippedBall.vfx === 'burst') createParticles(newX, newY, VFX_PARTICLE_COUNT, equippedBall.color, 4);
          const currentHitPaddleConfig = hitPaddle === 1 ? equippedPaddle : (mode === GameMode.TwoPlayer ? equippedPaddle : { vfx: 'glow-hit', color: 'bg-cyan-400', glowColor: 'shadow-cyan-400/70' }); 
          if (currentHitPaddleConfig.vfx === 'spark') createParticles(hitPaddle === 1 ? newX - BALL_RADIUS : newX + BALL_RADIUS, newY, VFX_PARTICLE_COUNT, 'bg-yellow-400', 3);
          if (currentHitPaddleConfig.vfx === 'shield') {
             const effect = { type: 'shield' as 'shield', activeUntil: Date.now() + VFX_PADDLE_EFFECT_DURATION };
             if (hitPaddle === 1) setPaddle1Effect(effect); else setPaddle2Effect(effect);
          }
          if (currentHitPaddleConfig.vfx === 'glow-hit') {
            const effect = { type: 'glow-hit' as 'glow-hit', activeUntil: Date.now() + VFX_PADDLE_EFFECT_DURATION, currentGlow: currentHitPaddleConfig.glowColor };
            if (hitPaddle === 1) setPaddle1Effect(effect); else setPaddle2Effect(effect);
          }
        }
        
        let collectedOrb: SpeedOrb | null = null;
        for (const orb of speedOrbs) {
            const distX = newX - orb.x; const distY = newY - orb.y;
            const distance = Math.sqrt(distX * distX + distY * distY);
            if (distance < BALL_RADIUS + orb.radius) { collectedOrb = orb; break; }
        }

        if (collectedOrb) {
            playSound('ORB_COLLECT');
            setActiveBoosts(prev => [...prev, {
                id: `boost-${Date.now()}`, boostAmount: collectedOrb!.boostAmount,
                expiresAt: Date.now() + collectedOrb!.boostDuration, orbType: collectedOrb!.type,
            }]);
            setSpeedOrbs(prevOrbs => prevOrbs.filter(o => o.id !== collectedOrb!.id));
            createParticles(collectedOrb.x, collectedOrb.y, VFX_PARTICLE_COUNT / 2, collectedOrb.color, 2); 
        }

        let finalSpeedMagnitude = Math.sqrt(newVx**2 + newVy**2);
        if (finalSpeedMagnitude > MAX_ALLOWABLE_SPEED) {
            const capRatio = MAX_ALLOWABLE_SPEED / finalSpeedMagnitude;
            newVx *= capRatio; newVy *= capRatio;
        }

        if (newX - BALL_RADIUS < 0) { 
          const newPlayer2Score = scores.player2 + 1;
          setScores(s => ({ ...s, player2: newPlayer2Score }));
          playSound('SCORE_P2');
          if (newPlayer2Score >= currentWinningScore) {
            setGameState('GAME_OVER'); setWinner(mode === GameMode.TwoPlayer ? 'Player 2' : 'AI');
            playSound('GAME_OVER_LOSE');
          } else resetBall(1);
        } else if (newX + BALL_RADIUS > GAME_WIDTH) { 
          const newPlayer1Score = scores.player1 + 1;
          setScores(s => ({ ...s, player1: newPlayer1Score }));
          playSound('SCORE_P1');
           if (newPlayer1Score >= currentWinningScore) {
            setGameState('GAME_OVER'); setWinner('Player 1');
            const coinsEarned = calculateMatchReward(mode as GameMode, currentWinningScore);
            if (coinsEarned > 0) addCoins(coinsEarned); // addCoins plays its own sound
            playSound('GAME_OVER_WIN');
          } else resetBall(2);
        }
        
        return { x: newX, y: newY, vx: newVx, vy: newVy };
      });
      
      gameLoopFrameId.current = requestAnimationFrame(gameLoop);
    };

    gameLoopFrameId.current = requestAnimationFrame(gameLoop);
    return () => {
      if (gameLoopFrameId.current) cancelAnimationFrame(gameLoopFrameId.current);
      gameLoopFrameId.current = null;
    };
  }, [gameState, player1PaddleY, player2PaddleY, resetBall, mode, equippedBall, equippedPaddle, addCoins, scores.player1, scores.player2, PADDLE_WIDTH, MAX_ALLOWABLE_SPEED, speedOrbs, ball.x, ball.y, activeBoosts, currentWinningScore]);

  useEffect(() => {
    if (gameState === 'PLAYING' && mode !== GameMode.TwoPlayer) {
      const aiSpeed = mode === GameMode.OnePVsAI_Easy ? AI_PADDLE_SPEED_EASY : 
                      mode === GameMode.OnePVsAI_Medium ? AI_PADDLE_SPEED_MEDIUM : AI_PADDLE_SPEED_HARD;
      setPlayer2PaddleY(prevY => {
        const targetY = ball.y - PADDLE_HEIGHT / 2;
        let newY = prevY;
        const reactionOffset = (Math.random() - 0.5) * PADDLE_HEIGHT * 0.3; 
        if (prevY < targetY + reactionOffset) newY = Math.min(prevY + aiSpeed, targetY + reactionOffset);
        else if (prevY > targetY + reactionOffset) newY = Math.max(prevY - aiSpeed, targetY + reactionOffset);
        return Math.max(0, Math.min(newY, GAME_HEIGHT - PADDLE_HEIGHT));
      });
    }
  }, [ball.y, gameState, mode]); 

  const handleControlPress = useCallback((controlKey: string) => { keysPressed.current[controlKey] = true; }, []);
  const handleControlRelease = useCallback((controlKey: string) => { keysPressed.current[controlKey] = false; }, []);
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = true;
       if (e.key === ' ' && (gameState === 'PRE_SERVE' || gameState === 'GAME_OVER')) {
         if (gameState === 'GAME_OVER') resetGame();
         else setGameState('PLAYING'); // Sound handled by useEffect watching gameState
       }
       if (e.key.toLowerCase() === 'p' && (gameState === 'PLAYING' || gameState === 'PAUSED')) {
          setGameState(gs => gs === 'PLAYING' ? 'PAUSED' : 'PLAYING'); // Sound handled by useEffect
       }
    };
    const handleKeyUp = (e: KeyboardEvent) => { keysPressed.current[e.key.toLowerCase()] = false; };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let paddleMoveFrameId: number;
    const movePaddles = () => {
      if (gameState === 'PLAYING') { 
        if (keysPressed.current['w'] || keysPressed.current[TOUCH_P1_UP]) setPlayer1PaddleY(y => Math.max(0, y - PADDLE_SPEED));
        if (keysPressed.current['s'] || keysPressed.current[TOUCH_P1_DOWN]) setPlayer1PaddleY(y => Math.min(GAME_HEIGHT - PADDLE_HEIGHT, y + PADDLE_SPEED));
        if (mode === GameMode.TwoPlayer) {
          if (keysPressed.current['arrowup'] || keysPressed.current[TOUCH_P2_UP]) setPlayer2PaddleY(y => Math.max(0, y - PADDLE_SPEED));
          if (keysPressed.current['arrowdown'] || keysPressed.current[TOUCH_P2_DOWN]) setPlayer2PaddleY(y => Math.min(GAME_HEIGHT - PADDLE_HEIGHT, y + PADDLE_SPEED));
        }
      }
      paddleMoveFrameId = requestAnimationFrame(movePaddles);
    };
    paddleMoveFrameId = requestAnimationFrame(movePaddles);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelAnimationFrame(paddleMoveFrameId);
      Object.keys(keysPressed.current).forEach(key => { keysPressed.current[key] = false; });
    };
  }, [gameState, mode, resetGame]);


  useEffect(() => {
    if (winner) {
      let message = `${winner === 'AI' ? 'The AI' : winner} wins!`;
      if (winner === 'Player 1') {
          const coinsEarned = calculateMatchReward(mode as GameMode, currentWinningScore);
          if (coinsEarned > 0) message += ` You earned ${coinsEarned} coins.`;
      }
      setModalContent({ title: 'Game Over!', message: message });
      setIsModalOpen(true); // Modal open sound handled by Modal component
    }
  }, [winner, mode, currentWinningScore]);

  const handleGameAreaClick = () => {
    if (gameState === 'PRE_SERVE') {
        setGameState('PLAYING'); // Sound handled by useEffect watching gameState
    } else if (gameState === 'GAME_OVER') {
        playSound('CLICK'); // For the click itself before reset
        resetGame();
        // setGameState is PRE_SERVE by resetGame
    }
  };

  const handlePauseResumeClick = () => {
    setGameState(gs => gs === 'PAUSED' ? 'PLAYING' : (gs === 'PLAYING' ? 'PAUSED' : gs));
     // Sound is handled by NeonButton click and then by useEffect watching gameState
  };
  
  return (
    <div className="flex flex-col items-center">
      <div className="flex justify-between w-full max-w-3xl mb-2 px-2">
        <NeonButton size="sm" color="pink" onClick={() => { playSound('NAVIGATE'); navigate('/'); }}>Back to Menu</NeonButton>
        <h2 className="text-2xl text-slate-300">{mode?.replace('-', ' VS ').replace('1p', 'Player 1').toUpperCase()} (First to {currentWinningScore})</h2>
        {gameState !== 'GAME_OVER' && (
            <NeonButton size="sm" color="yellow" 
                onClick={handlePauseResumeClick}
                disabled={gameState === 'PRE_SERVE'}>
            {gameState === 'PAUSED' ? 'Resume' : 'Pause'}
            </NeonButton>
        )}
      </div>

      <div 
        ref={gameAreaRef} 
        className="relative bg-slate-900 border-4 border-cyan-600 shadow-[0_0_20px_rgba(6,182,212,0.5)] overflow-hidden touch-none select-none"
        style={{ width: GAME_WIDTH, height: GAME_HEIGHT, cursor: (gameState === 'PRE_SERVE' || gameState === 'GAME_OVER') ? 'pointer' : 'default' }}
        onClick={handleGameAreaClick}
        role="application" aria-label="Ping Pong Game Area" tabIndex={0} 
      >
        <div className="absolute top-4 left-1/2 -translate-x-1/2 flex gap-12 text-5xl font-bold z-10 pointer-events-none" aria-live="polite">
          <span className="text-pink-500 neon-text-pink" aria-label={`Player 1 score: ${scores.player1}`}>{scores.player1}</span>
          <span className="text-cyan-400 neon-text-cyan" aria-label={`Player 2 score: ${scores.player2}`}>{scores.player2}</span>
        </div>
        
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1 h-full bg-slate-700 opacity-50 pointer-events-none" aria-hidden="true">
            {[...Array(Math.floor(GAME_HEIGHT / 20))].map((_, i) => (
                <div key={i} className="h-[10px] w-full bg-cyan-500/50 mb-[10px]"></div>
            ))}
        </div>

        <div 
          className={`absolute ${paddle1Effect.type === 'glow-hit' && paddle1Effect.currentGlow ? paddle1Effect.currentGlow.replace('/70', '/95') : equippedPaddle.glowColor} shadow-lg pointer-events-none`}
          style={{ left: 0, top: player1PaddleY, width: PADDLE_WIDTH, height: PADDLE_HEIGHT, backgroundColor: colorToVarStyle(equippedPaddle.color), transition: 'box-shadow 0.1s ease-out' }}
          aria-label="Player 1 Paddle"
        />
        {paddle1Effect.type === 'shield' && Date.now() < paddle1Effect.activeUntil && (
            <div className="absolute pointer-events-none" style={{
                left: -PADDLE_WIDTH * 0.1, top: player1PaddleY - PADDLE_HEIGHT * 0.05, width: PADDLE_WIDTH * 1.2, height: PADDLE_HEIGHT * 1.1,
                backgroundColor: colorToVarStyle(equippedPaddle.color), opacity: 0.4, borderRadius: '4px', border: `2px solid ${colorToVarStyle(equippedPaddle.color)}`
            }} />
        )}

        <div 
           className={`absolute ${paddle2Effect.type === 'glow-hit' && paddle2Effect.currentGlow ? paddle2Effect.currentGlow.replace('/70', '/95') : (mode === GameMode.TwoPlayer ? equippedPaddle.glowColor : 'shadow-cyan-400/70')} shadow-lg pointer-events-none`}
          style={{ right: 0, top: player2PaddleY, width: PADDLE_WIDTH, height: PADDLE_HEIGHT, backgroundColor: colorToVarStyle(mode === GameMode.TwoPlayer ? equippedPaddle.color : 'bg-cyan-400'), transition: 'box-shadow 0.1s ease-out' }}
          aria-label={mode === GameMode.TwoPlayer ? "Player 2 Paddle" : "AI Paddle"}
        />
         {paddle2Effect.type === 'shield' && Date.now() < paddle2Effect.activeUntil && (
            <div className="absolute pointer-events-none" style={{
                right: -PADDLE_WIDTH * 0.1, top: player2PaddleY - PADDLE_HEIGHT * 0.05, width: PADDLE_WIDTH * 1.2, height: PADDLE_HEIGHT * 1.1,
                backgroundColor: colorToVarStyle(mode === GameMode.TwoPlayer ? equippedPaddle.color : 'bg-cyan-400'), opacity: 0.4, borderRadius: '4px', border: `2px solid ${colorToVarStyle(mode === GameMode.TwoPlayer ? equippedPaddle.color : 'bg-cyan-400')}`
            }} />
        )}

        {speedOrbs.map(orb => (
          <div
            key={orb.id}
            className={`absolute rounded-full ${orb.glowColor} shadow-md pointer-events-none animate-pulse`}
            style={{ left: orb.x - orb.radius, top: orb.y - orb.radius, width: orb.radius * 2, height: orb.radius * 2, backgroundColor: colorToVarStyle(orb.color), zIndex: 5 }}
            aria-label={`Speed Orb ${orb.type}`}
          />
        ))}

        {equippedBall.vfx === 'trail' && ballTrail.map((p, i) => (
          <div key={`trail-${i}`} className="absolute rounded-full pointer-events-none" style={{
            left: p.x - BALL_RADIUS * p.opacity * 0.8, top: p.y - BALL_RADIUS * p.opacity * 0.8,
            width: BALL_RADIUS * 2 * p.opacity * 0.8, height: BALL_RADIUS * 2 * p.opacity * 0.8,
            backgroundColor: colorToVarStyle(equippedBall.color), opacity: p.opacity * 0.5, zIndex: 8
          }} />
        ))}
        
        <div 
          className={`absolute rounded-full ${equippedBall.glowColor} shadow-xl pointer-events-none`}
          style={{ left: ball.x - BALL_RADIUS, top: ball.y - BALL_RADIUS, width: BALL_RADIUS * 2, height: BALL_RADIUS * 2, backgroundColor: colorToVarStyle(equippedBall.color), zIndex: 10 }}
          aria-label="Ball"
        />

        {activeParticles.map(p => (
          <div key={p.id} className="absolute rounded-full pointer-events-none" style={{
            left: p.x - p.size / 2, top: p.y - p.size / 2, width: p.size, height: p.size,
            backgroundColor: p.color, opacity: p.life / VFX_PARTICLE_LIFESPAN_FRAMES, zIndex: 15
          }}/>
        ))}
        
        <div className="absolute bottom-3 left-3 flex gap-3 z-30">
            <button
            className="w-24 h-16 bg-slate-800/60 text-cyan-300 rounded-lg flex items-center justify-center text-4xl focus:outline-none active:bg-cyan-600/60 shadow-lg shadow-cyan-500/40 hover:shadow-cyan-400/50 transition-all"
            onTouchStart={(e) => { e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P1_UP);}} onTouchEnd={(e) => { e.preventDefault(); handleControlRelease(TOUCH_P1_UP);}}
            onMouseDown={(e) => {e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P1_UP);}} onMouseUp={(e) => {e.preventDefault(); handleControlRelease(TOUCH_P1_UP);}}
            onMouseLeave={(e) => { if(keysPressed.current[TOUCH_P1_UP]) {e.preventDefault(); handleControlRelease(TOUCH_P1_UP);}}}
            aria-label="Player 1 Move Up"
            >▲</button>
            <button
            className="w-24 h-16 bg-slate-800/60 text-cyan-300 rounded-lg flex items-center justify-center text-4xl focus:outline-none active:bg-cyan-600/60 shadow-lg shadow-cyan-500/40 hover:shadow-cyan-400/50 transition-all"
            onTouchStart={(e) => { e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P1_DOWN);}} onTouchEnd={(e) => { e.preventDefault(); handleControlRelease(TOUCH_P1_DOWN);}}
            onMouseDown={(e) => {e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P1_DOWN);}} onMouseUp={(e) => {e.preventDefault(); handleControlRelease(TOUCH_P1_DOWN);}}
            onMouseLeave={(e) => { if(keysPressed.current[TOUCH_P1_DOWN]) {e.preventDefault(); handleControlRelease(TOUCH_P1_DOWN);}}}
            aria-label="Player 1 Move Down"
            >▼</button>
        </div>

        {mode === GameMode.TwoPlayer && (
            <div className="absolute bottom-3 right-3 flex gap-3 z-30">
                <button
                className="w-24 h-16 bg-slate-800/60 text-pink-400 rounded-lg flex items-center justify-center text-4xl focus:outline-none active:bg-pink-600/60 shadow-lg shadow-pink-500/40 hover:shadow-pink-400/50 transition-all"
                onTouchStart={(e) => { e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P2_UP);}} onTouchEnd={(e) => { e.preventDefault(); handleControlRelease(TOUCH_P2_UP);}}
                onMouseDown={(e) => {e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P2_UP);}} onMouseUp={(e) => {e.preventDefault(); handleControlRelease(TOUCH_P2_UP);}}
                onMouseLeave={(e) => { if(keysPressed.current[TOUCH_P2_UP]) {e.preventDefault(); handleControlRelease(TOUCH_P2_UP);}}}
                aria-label="Player 2 Move Up"
                >▲</button>
                <button
                className="w-24 h-16 bg-slate-800/60 text-pink-400 rounded-lg flex items-center justify-center text-4xl focus:outline-none active:bg-pink-600/60 shadow-lg shadow-pink-500/40 hover:shadow-pink-400/50 transition-all"
                onTouchStart={(e) => { e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P2_DOWN);}} onTouchEnd={(e) => { e.preventDefault(); handleControlRelease(TOUCH_P2_DOWN);}}
                onMouseDown={(e) => {e.preventDefault(); playSound('CLICK', 0.4); handleControlPress(TOUCH_P2_DOWN);}} onMouseUp={(e) => {e.preventDefault(); handleControlRelease(TOUCH_P2_DOWN);}}
                onMouseLeave={(e) => { if(keysPressed.current[TOUCH_P2_DOWN]) {e.preventDefault(); handleControlRelease(TOUCH_P2_DOWN);}}}
                aria-label="Player 2 Move Down"
                >▼</button>
            </div>
        )}

        {(gameState === 'PRE_SERVE' && !winner) && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 z-20 pointer-events-none">
            <p className="text-3xl text-yellow-300 neon-text-yellow mb-4 animate-pulse text-center px-4">Press SPACE or Click Game Area to Serve</p>
            <div className="pointer-events-auto"> 
              <NeonButton onClick={() => setGameState('PLAYING')} color="emerald">Start Match</NeonButton>
            </div>
          </div>
        )}
        {gameState === 'PAUSED' && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/70 z-20 pointer-events-none">
                <p className="text-5xl text-yellow-400 neon-text-yellow animate-pulse">PAUSED</p>
            </div>
        )}
      </div>
      
      <div className="mt-4 text-center text-xs text-slate-400 w-full max-w-md px-2">
        {mode === GameMode.TwoPlayer && <p>P1: W/S or Left Controls | P2: Arrow Keys or Right Controls</p>}
        {mode !== GameMode.TwoPlayer && <p>Controls: W/S or On-Screen Controls, P (Pause/Resume)</p>}
        <p>Space or Click game area to Serve/Restart after game over.</p>
      </div>
      <div className="mt-2 text-xs text-slate-500">Current Ball: {equippedBall.name}, Paddle: {equippedPaddle.name}</div>

      <Modal isOpen={isModalOpen && gameState === 'GAME_OVER'} onClose={() => { setIsModalOpen(false); playSound('NAVIGATE'); navigate('/');}} title={modalContent.title}>
        <p className="text-xl text-center mb-6">{modalContent.message}</p>
        <div className="flex justify-around">
            <NeonButton color="cyan" onClick={() => { resetGame(); setIsModalOpen(false); /* PRE_SERVE set by resetGame */ }}>Play Again</NeonButton>
            <NeonButton color="pink" onClick={() => { playSound('NAVIGATE'); navigate('/'); }}>Main Menu</NeonButton>
        </div>
      </Modal>
    </div>
  );
};

export default GameScreen;
