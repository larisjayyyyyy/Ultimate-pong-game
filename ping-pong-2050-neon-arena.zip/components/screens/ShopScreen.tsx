
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePlayerData } from '../../hooks/usePlayerData';
import { BALLS, PADDLES, POWER_UPS } from '../../constants';
import NeonButton from '../common/NeonButton';
import ItemCard from '../common/ItemCard';
import { Ball, Paddle, PowerUp } from '../../types';
import Modal from '../common/Modal';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';


const ShopScreen: React.FC = () => {
  const navigate = useNavigate();
  const { playerData, buyBall, buyPaddle, isBallOwned, isPaddleOwned, spendCoins } = usePlayerData();
  const [activeTab, setActiveTab] = useState<'balls' | 'paddles' | 'powerups'>('balls');
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState('');

  const handleBuyBall = (ball: Ball) => {
    if (buyBall(ball)) { // buyBall plays its own sounds
        setModalMessage(`Successfully purchased ${ball.name}!`);
    } else {
        setModalMessage(`Failed to purchase ${ball.name}. Not enough coins or already owned.`);
    }
    setModalOpen(true); // Modal component plays its open sound
  };

  const handleBuyPaddle = (paddle: Paddle) => {
    if (buyPaddle(paddle)) { // buyPaddle plays its own sounds
        setModalMessage(`Successfully purchased ${paddle.name}!`);
    } else {
        setModalMessage(`Failed to purchase ${paddle.name}. Not enough coins or already owned.`);
    }
    setModalOpen(true); // Modal component plays its open sound
  };

  const handleBuyPowerUp = (powerUp: PowerUp) => {
    if (playerData.coins >= powerUp.cost) {
        if(spendCoins(powerUp.cost)) { // spendCoins doesn't play sound by default
          playSound('BUY_ITEM');
          // Add power-up to player inventory (to be implemented in usePlayerData)
          // For now, just assume purchase is successful for sound purposes
          // playerData.powerUps[powerUp.id] = (playerData.powerUps[powerUp.id] || 0) + 1; // Example: if count based
          setModalMessage(`Successfully purchased ${powerUp.name}!`);
        } else { // Should not happen if playerData.coins check passes, but as a fallback
          playSound('ERROR');
          setModalMessage(`Purchase failed for ${powerUp.name}.`);
        }
    } else {
        playSound('ERROR');
        setModalMessage(`Not enough coins to purchase ${powerUp.name}.`);
    }
    setModalOpen(true); // Modal component plays its open sound
  };

  const handleTabChange = (tab: 'balls' | 'paddles' | 'powerups') => {
    playSound('CLICK');
    setActiveTab(tab);
  };

  return (
    <div className="w-full max-w-4xl flex flex-col items-center p-4">
      <div className="flex justify-between items-center w-full mb-6">
        <NeonButton color="pink" onClick={() => { playSound('NAVIGATE'); navigate('/'); }} size="sm">
          &larr; Back to Menu
        </NeonButton>
        <h1 className="text-4xl font-bold text-pink-500 neon-text-pink">Shop</h1>
        <div className="bg-slate-800/70 border border-cyan-600 px-3 py-1.5 rounded-lg shadow-md">
          <p className="text-yellow-400 text-md">Coins: <span className="font-bold">{playerData.coins}</span></p>
        </div>
      </div>

      <div className="mb-6 flex gap-3">
        <NeonButton onClick={() => handleTabChange('balls')} color={activeTab === 'balls' ? 'cyan' : 'pink'} className={activeTab === 'balls' ? 'opacity-100' : 'opacity-60'}>Balls</NeonButton>
        <NeonButton onClick={() => handleTabChange('paddles')} color={activeTab === 'paddles' ? 'cyan' : 'pink'} className={activeTab === 'paddles' ? 'opacity-100' : 'opacity-60'}>Paddles</NeonButton>
        <NeonButton onClick={() => handleTabChange('powerups')} color={activeTab === 'powerups' ? 'cyan' : 'pink'} className={activeTab === 'powerups' ? 'opacity-100' : 'opacity-60'}>Power-ups</NeonButton>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 w-full">
        {activeTab === 'balls' && BALLS.map(ball => (
          <ItemCard 
            key={ball.id} 
            item={ball} 
            onAction={() => handleBuyBall(ball)} // NeonButton in ItemCard plays CLICK
            actionLabel="Buy"
            isOwned={isBallOwned(ball.id)}
            canAfford={playerData.coins >= ball.cost}
          />
        ))}
        {activeTab === 'paddles' && PADDLES.map(paddle => (
          <ItemCard 
            key={paddle.id} 
            item={paddle}
            onAction={() => handleBuyPaddle(paddle)} // NeonButton in ItemCard plays CLICK
            actionLabel="Buy"
            isOwned={isPaddleOwned(paddle.id)}
            canAfford={playerData.coins >= paddle.cost}
          />
        ))}
        {activeTab === 'powerups' && POWER_UPS.map(powerUp => (
            <div key={powerUp.id} className="bg-slate-800 border-2 border-slate-700 rounded-lg p-4 flex flex-col items-center gap-3 hover:border-yellow-500 transition-all">
                <div className="w-16 h-16 rounded-full bg-yellow-500 flex items-center justify-center text-2xl font-bold shadow-lg shadow-yellow-500/50">⚡</div>
                <h3 className="text-xl font-bold text-slate-100">{powerUp.name}</h3>
                <p className="text-sm text-slate-400 text-center h-10 overflow-y-auto">{powerUp.description}</p>
                <NeonButton 
                    onClick={() => handleBuyPowerUp(powerUp)} // NeonButton plays CLICK, handleBuyPowerUp plays BUY_ITEM/ERROR
                    disabled={playerData.coins < powerUp.cost}
                    color="yellow" 
                    size="sm"
                >
                    Buy ({powerUp.cost} Coins)
                </NeonButton>
                 {playerData.coins < powerUp.cost && <p className="text-xs text-red-500">Not enough coins</p>}
            </div>
        ))}
      </div>
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Shop Notification">
          <p>{modalMessage}</p>
      </Modal>
    </div>
  );
};

export default ShopScreen;
