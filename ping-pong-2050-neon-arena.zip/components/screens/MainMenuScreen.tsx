
import React from 'react';
import { useNavigate } from 'react-router-dom';
import NeonButton from '../common/NeonButton';
import { usePlayerData } from '../../hooks/usePlayerData';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';

// Simple SVG for decorative table
const PingPongTableSVG: React.FC = () => (
  <svg viewBox="0 0 400 250" className="w-full max-w-lg h-auto drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">
    {/* Perspective Table Outline */}
    <polygon points="50,50 350,50 300,200 100,200" fill="rgba(6,182,212,0.1)" stroke="#06b6d4" strokeWidth="3"/>
    {/* Center Line */}
    <line x1="200" y1="50" x2="200" y2="200" stroke="#06b6d4" strokeWidth="2" strokeDasharray="5,5"/>
    {/* Net */}
    <line x1="85" y1="125" x2="315" y2="125" stroke="#06b6d4" strokeWidth="10" strokeOpacity="0.5"/>
    <line x1="85" y1="125" x2="315" y2="125" stroke="#08f7fe" strokeWidth="3"/>
    {/* Decorative paddles */}
    <rect x="130" y="150" width="15" height="40" fill="#ec4899" rx="3" opacity="0.7"/>
    <rect x="255" y="60" width="15" height="40" fill="#06b6d4" rx="3" opacity="0.7"/>
    {/* Decorative Ball */}
    <circle cx="230" cy="100" r="7" fill="#ec4899" opacity="0.8"/>
  </svg>
);


const MainMenuScreen: React.FC = () => {
  const navigate = useNavigate();
  const { playerData } = usePlayerData();

  const handleNavigate = (path: string) => {
    playSound('NAVIGATE');
    navigate(path);
  };

  return (
    <div className="w-full max-w-2xl flex flex-col items-center justify-center text-center p-4 min-h-[calc(100vh-4rem)]">
      <header className="absolute top-4 right-4">
        <div className="bg-slate-800/70 border border-cyan-600 px-4 py-2 rounded-lg shadow-md">
            <p className="text-yellow-400 text-lg">Coins: <span className="font-bold">{playerData.coins}</span></p>
        </div>
      </header>

      <div className="mb-8 md:mb-12">
        <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold text-cyan-400 neon-text-cyan">
          PING PONG
        </h1>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-pink-500 neon-text-pink">
          2050
        </h2>
      </div>

      <div className="mb-10 w-full px-4">
        <PingPongTableSVG />
      </div>
      
      <nav className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-md">
        <NeonButton color="cyan" size="lg" onClick={() => handleNavigate('/settings')} className="w-full">
          PLAY
        </NeonButton>
        <NeonButton color="pink" size="lg" onClick={() => handleNavigate('/shop')} className="w-full">
          SHOP
        </NeonButton>
        <NeonButton color="emerald" size="lg" onClick={() => handleNavigate('/customize')} className="w-full">
          CUSTOMIZE
        </NeonButton>
         <NeonButton color="yellow" size="lg" onClick={() => handleNavigate('/settings')} className="w-full">
          SETTINGS
        </NeonButton>
      </nav>
      
      <footer className="mt-12 text-slate-500 text-sm">
        <p>&copy; 2024 Neon Arena Games. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default MainMenuScreen;
