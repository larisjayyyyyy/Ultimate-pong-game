
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GameMode } from '../../types';
import NeonButton from '../common/NeonButton';
import Modal from '../common/Modal';
import { 
  DEFAULT_WINNING_SCORE, 
  MIN_POINTS_TO_WIN, 
  MAX_POINTS_TO_WIN,
  COIN_REWARDS,
  COIN_BONUS_PER_POINT_ABOVE_DEFAULT 
} from '../../constants';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';

const SettingsScreen: React.FC = () => {
  const navigate = useNavigate();
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [selectedGameMode, setSelectedGameMode] = useState<GameMode | null>(null);
  const [pointsToWinInput, setPointsToWinInput] = useState(String(DEFAULT_WINNING_SCORE));

  const calculateMatchReward = (mode: GameMode, targetPoints: number): number => {
    const baseReward = COIN_REWARDS[mode as keyof typeof COIN_REWARDS] || 0;
    if (targetPoints <= 0) return 0;
  
    const bonusPoints = Math.max(0, targetPoints - DEFAULT_WINNING_SCORE);
    const bonusPerPoint = COIN_BONUS_PER_POINT_ABOVE_DEFAULT[mode as keyof typeof COIN_BONUS_PER_POINT_ABOVE_DEFAULT] || 0;
    
    return baseReward + (bonusPoints * bonusPerPoint);
  };

  const openConfigModal = (mode: GameMode) => {
    setSelectedGameMode(mode);
    setPointsToWinInput(String(DEFAULT_WINNING_SCORE));
    setIsConfigModalOpen(true); // Modal component handles its open sound
    // NeonButton that calls this already played a CLICK sound
  };

  const handleStartGame = () => {
    if (!selectedGameMode) return;

    const numericPoints = parseInt(pointsToWinInput, 10);
    if (isNaN(numericPoints) || numericPoints < MIN_POINTS_TO_WIN || numericPoints > MAX_POINTS_TO_WIN) {
      playSound('ERROR');
      alert(`Please enter a whole number between ${MIN_POINTS_TO_WIN} and ${MAX_POINTS_TO_WIN} for points to win.`);
      return;
    }
    // NeonButton plays CLICK, then NAVIGATE for screen transition
    playSound('NAVIGATE');
    navigate(`/play/${selectedGameMode}/${numericPoints}`);
    setIsConfigModalOpen(false); // Modal onClose will play its sound if configured (or Modal's X button)
  };

  const getGameModeName = (mode: GameMode | null) => {
    if (!mode) return '';
    switch(mode) {
      case GameMode.OnePVsAI_Easy: return 'AI Easy';
      case GameMode.OnePVsAI_Medium: return 'AI Medium';
      case GameMode.OnePVsAI_Hard: return 'AI Hard';
      case GameMode.TwoPlayer: return '2 Players (Local)';
      default: return '';
    }
  };
  
  let estimatedRewardText = 'N/A';
  if (selectedGameMode) {
    const numPoints = parseInt(pointsToWinInput);
    if (!isNaN(numPoints) && numPoints >= MIN_POINTS_TO_WIN && numPoints <= MAX_POINTS_TO_WIN) {
        const calculated = calculateMatchReward(selectedGameMode, numPoints);
        estimatedRewardText = String(calculated);
    }
  }


  return (
    <div className="w-full max-w-lg flex flex-col items-center p-4">
      <div className="flex justify-between items-center w-full mb-8">
        <NeonButton 
            color="pink" 
            onClick={() => { playSound('NAVIGATE'); navigate('/'); }} 
            size="sm" 
            aria-label="Back to Main Menu"
        >
          &larr; Back to Menu
        </NeonButton>
        <h1 className="text-4xl font-bold text-yellow-400 neon-text-yellow">Game Modes</h1>
        <div /> {/* Spacer */}
      </div>

      <div className="space-y-6 w-full">
        <div>
            <h2 className="text-2xl text-cyan-300 mb-3 text-center">Single Player VS AI</h2>
            <div className="grid grid-cols-1 gap-4">
                <NeonButton color="cyan" size="lg" onClick={() => openConfigModal(GameMode.OnePVsAI_Easy)}>
                AI Easy
                </NeonButton>
                <NeonButton color="cyan" size="lg" onClick={() => openConfigModal(GameMode.OnePVsAI_Medium)}>
                AI Medium
                </NeonButton>
                <NeonButton color="cyan" size="lg" onClick={() => openConfigModal(GameMode.OnePVsAI_Hard)}>
                AI Hard
                </NeonButton>
            </div>
        </div>
        
        <div>
            <h2 className="text-2xl text-pink-400 mb-3 text-center">Multiplayer</h2>
            <div className="grid grid-cols-1 gap-4">
                <NeonButton color="pink" size="lg" onClick={() => openConfigModal(GameMode.TwoPlayer)}>
                2 Players (Local)
                </NeonButton>
            </div>
        </div>
      </div>

       <div className="mt-12 p-4 bg-slate-800/50 border border-slate-700 rounded-lg w-full">
        <h3 className="text-xl text-slate-300 mb-2 text-center">Other Settings</h3>
        <p className="text-slate-500 text-center text-sm">
            (Sound, Music, Controls customization - Coming Soon!)
        </p>
      </div>

      <Modal 
        isOpen={isConfigModalOpen} 
        onClose={() => setIsConfigModalOpen(false)} // Modal handles its own close sound via its 'x' button
        title={`Configure Match: ${getGameModeName(selectedGameMode)}`}
      >
        <div className="space-y-4">
          <div>
            <label htmlFor="pointsToWin" className="block text-sm font-medium text-slate-300 mb-1">
              Points to Win ({MIN_POINTS_TO_WIN}-{MAX_POINTS_TO_WIN}):
            </label>
            <input
              type="number"
              id="pointsToWin"
              name="pointsToWin"
              value={pointsToWinInput}
              onChange={(e) => setPointsToWinInput(e.target.value)}
              min={MIN_POINTS_TO_WIN}
              max={MAX_POINTS_TO_WIN}
              className="w-full bg-slate-700 border border-slate-600 text-slate-100 rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500"
            />
          </div>
          <p className="mt-1 text-sm text-slate-400">
            Estimated Coin Reward (if P1 wins): <span className="text-yellow-400 font-bold">{estimatedRewardText}</span>
          </p>
          <div className="flex justify-end gap-3 pt-2">
            <NeonButton color="pink" onClick={() => { playSound('CLICK'); setIsConfigModalOpen(false); }} size="md">
              Cancel
            </NeonButton>
            <NeonButton color="emerald" onClick={handleStartGame} size="md">
              Start Match
            </NeonButton>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default SettingsScreen;
