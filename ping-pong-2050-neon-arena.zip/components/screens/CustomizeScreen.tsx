
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePlayerData } from '../../hooks/usePlayerData';
import { BALLS, PADDLES } from '../../constants';
import NeonButton from '../common/NeonButton';
import ItemCard from '../common/ItemCard';
import playSound, { SOUND_FILES, SoundKey } from '../../lib/SoundService';

const CustomizeScreen: React.FC = () => {
  const navigate = useNavigate();
  const { playerData, equipBall, equipPaddle, isBallOwned, isPaddleOwned } = usePlayerData();
  const [activeTab, setActiveTab] = useState<'balls' | 'paddles'>('balls');

  const handleTabChange = (tab: 'balls' | 'paddles') => {
    playSound('CLICK');
    setActiveTab(tab);
  };

  return (
    <div className="w-full max-w-4xl flex flex-col items-center p-4">
      <div className="flex justify-between items-center w-full mb-6">
        <NeonButton color="pink" onClick={() => { playSound('NAVIGATE'); navigate('/'); }} size="sm">
          &larr; Back to Menu
        </NeonButton>
        <h1 className="text-4xl font-bold text-emerald-400 neon-text-emerald">Customize</h1>
        <div className="bg-slate-800/70 border border-cyan-600 px-3 py-1.5 rounded-lg shadow-md">
          <p className="text-yellow-400 text-md">Coins: <span className="font-bold">{playerData.coins}</span></p>
        </div>
      </div>

      <div className="mb-6 flex gap-3">
        <NeonButton onClick={() => handleTabChange('balls')} color={activeTab === 'balls' ? 'cyan' : 'emerald'} className={activeTab === 'balls' ? 'opacity-100' : 'opacity-60'}>Balls</NeonButton>
        <NeonButton onClick={() => handleTabChange('paddles')} color={activeTab === 'paddles' ? 'cyan' : 'emerald'} className={activeTab === 'paddles' ? 'opacity-100' : 'opacity-60'}>Paddles</NeonButton>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 w-full">
        {activeTab === 'balls' && BALLS.filter(ball => isBallOwned(ball.id)).map(ball => (
          <ItemCard 
            key={ball.id} 
            item={ball} 
            isOwned={true}
            isEquipped={playerData.equippedBallId === ball.id}
            onEquip={() => equipBall(ball.id)} // equipBall in usePlayerData plays EQUIP_ITEM, NeonButton in ItemCard plays CLICK
          />
        ))}
        {activeTab === 'paddles' && PADDLES.filter(paddle => isPaddleOwned(paddle.id)).map(paddle => (
          <ItemCard 
            key={paddle.id} 
            item={paddle}
            isOwned={true}
            isEquipped={playerData.equippedPaddleId === paddle.id}
            onEquip={() => equipPaddle(paddle.id)} // equipPaddle in usePlayerData plays EQUIP_ITEM, NeonButton in ItemCard plays CLICK
          />
        ))}
      </div>
      {activeTab === 'balls' && BALLS.filter(ball => isBallOwned(ball.id)).length === 0 && (
        <p className="text-slate-400 col-span-full text-center mt-8">You don't own any balls yet. Visit the Shop!</p>
      )}
      {activeTab === 'paddles' && PADDLES.filter(paddle => isPaddleOwned(paddle.id)).length === 0 && (
        <p className="text-slate-400 col-span-full text-center mt-8">You don't own any paddles yet. Visit the Shop!</p>
      )}
    </div>
  );
};

export default CustomizeScreen;
