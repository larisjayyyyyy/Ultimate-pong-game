
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 bg-slate-950 flex flex-col items-center justify-center z-[100]">
      <h1 className="text-6xl md:text-8xl font-bold text-cyan-400 neon-text-cyan mb-4 animate-pulse">
        PING PONG
      </h1>
      <h2 className="text-4xl md:text-6xl font-bold text-pink-500 neon-text-pink mb-12 animate-pulse delay-500">
        2050
      </h2>
      <div className="w-20 h-20 border-4 border-t-transparent border-cyan-400 rounded-full animate-spin"></div>
      <p className="text-slate-400 mt-8 text-lg">Loading Neon Arena...</p>
    </div>
  );
};

export default LoadingScreen;
